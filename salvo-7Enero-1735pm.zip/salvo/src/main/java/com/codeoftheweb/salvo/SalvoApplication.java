package com.codeoftheweb.salvo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SalvoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalvoApplication.class, args);
	}

	@Bean
	public CommandLineRunner initData(PlayerRepository playerRepository){
		return (args) -> {
			// save a couple of customers
			playerRepository.save(new Player("Jack", "Bauer", "iWillFNDU"));
			playerRepository.save(new Player("Mister", "Jones", "smokeCave420"));
			playerRepository.save(new Player("Kim", "Jong-Il", "dictaThorShip"));
			playerRepository.save(new Player("David", "Beckham", "metroNomous"));
			playerRepository.save(new Player("Julian", "Martin Irigoyen",  "Shcaulman"));
		};
	}

}




